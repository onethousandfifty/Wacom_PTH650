# PTH-650: границы специализированного fork

## Неприкосновенные части исходного драйвера

Рабочий путь пера в Trifa Studio остаётся без изменений: `WacomModeSwitch.enableDigitizerMode`, обработка report ID `0x02`, `0x05`, `0x06`, `0x10`, декодирование давления/наклона и `TabletEventSynthesizer`. Предыдущая попытка не отправлять mode-switch на PTH-650 вызвала регрессию и полностью исключена из нового fork.

## Подтверждённая раскладка панели Intuos5 PTH-650

| Элемент | Значение |
|---|---|
| USB VID:PID | `056a:0027` |
| Модель | Wacom Intuos5 touch M / PTH-650 |
| Перьевые отчёты | Остаются на существующем пути Intuos в Trifa Studio |
| Отчёт панели | `0x03` — только короткий кадр панели; его нельзя спутать с Bluetooth batch Intuos4 |
| Touch Ring | `data[2]`, бит 7 = контакт с кольцом, биты 0…6 = положение |
| Центральная кнопка кольца | `data[3] & 0x01`; переключает один из четырёх режимов Touch Ring |
| ExpressKeys | `data[4]`; полный битовый набор панели: `(data[4] << 1) | (data[3] & 0x01)` |

## Ограничение

Длинные кадры touch не будут интерпретироваться как отчёты панели. Мультитач не является целью первого безопасного выпуска: его нельзя реализовывать без реального HID-лога от PTH-650 и отдельного синтеза жестов macOS.

## Источники

- https://github.com/linuxwacom/libwacom/blob/master/data/wacom-intuos5-touch-m.tablet
- https://github.com/torvalds/linux/blob/master/drivers/hid/wacom_wac.c
- https://101.wacom.com/UserHelp/en/TOC/PTH-651.html

## Personal repository

The user created a separate personal repository for this driver: https://github.com/onethousandfifty/Wacom_PTH650 . It is empty and public as of the check on 2026-08-25. No pull request to the Trifa Studio repository is authorized or planned.

- README was committed to `main` as commit `6b6f19ab7ed80eabfc1e00f7a3f942bfdddcba15` with the message `Initial personal PTH-650 headless driver`.

The browser session is authenticated as `onethousandfifty`; the repository page confirms the first commit is on the user's `main` branch.

The upstream MIT license is retained verbatim for publication in the personal fork.
