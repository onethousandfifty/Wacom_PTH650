# Recovery and first-run checklist

This repository is a separate PTH-650-only project. Do **not** apply its files as a patch over the previous experimental copy of `wacom-intuos4-driver`.

## Preserve the old working tree

If the old directory contains only the accidental `WacomModeSwitch.swift` edit, restore that one file without deleting unrelated work:

```bash
cd "$HOME/wacom-intuos4-driver"
git restore -- IntuosDriver/Sources/IntuosDriverCore/Protocol/WacomModeSwitch.swift
git status --short
```

If its status contains other experimental changes, keep the directory as evidence and do not use `git reset --hard`. The personal PTH-650 driver is built from a new clone of this repository instead.

## First run of the PTH-650 fork

```bash
cd "$HOME/pth650-driver/IntuosDriver"
swift run pth650-tests
swift build -c release
.build/release/pth650-driver --verbose
```

The original Trifa Studio `WacomModeSwitch` sequence is deliberately unchanged in the PTH-650 fork. It is started by `USBTransport` before raw reports are processed.

## If ExpressKeys or Touch Ring do not respond

Start diagnostic output and exercise only one control at a time:

```bash
.build/release/pth650-driver --verbose --hex | tee "$HOME/Desktop/pth650-hid.log"
```

Then share the resulting `pth650-hid.log`. The driver will print raw report ID, length and bytes, which allows the panel parser to be adjusted from the actual tablet trace rather than guessed data.
