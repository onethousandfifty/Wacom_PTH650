// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PTH650Driver",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "pth650-driver", targets: ["PTH650Driver"]),
        .executable(name: "pth650-tests", targets: ["PTH650TestRunner"])
    ],
    targets: [
        .target(
            name: "IntuosDriverCore",
            dependencies: [],
            path: "Sources/IntuosDriverCore"
        ),
        .executableTarget(
            name: "PTH650Driver",
            dependencies: ["IntuosDriverCore"],
            path: "Sources/PTH650Driver"
        ),
        .executableTarget(
            name: "PTH650TestRunner",
            dependencies: ["IntuosDriverCore"],
            path: "Sources/PTH650TestRunner"
        )
    ]
)
