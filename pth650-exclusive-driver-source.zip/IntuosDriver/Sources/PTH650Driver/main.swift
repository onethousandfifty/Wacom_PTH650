import Foundation
import IOKit
import IOKit.hid
import IntuosDriverCore

/// Headless personal driver for exactly one tablet: Wacom Intuos5 touch M PTH-650.
/// It deliberately has no menu bar UI, profiles, OLED control, Bluetooth support
/// or driver commands beyond the original proven Trifa Studio HID mode sequence.
final class PTH650Driver: USBTransportDelegate, @unchecked Sendable {
    private let decoder = WacomPacketDecoder()
    private let synthesizer = TabletEventSynthesizer()
    private let expressKeys = ExpressKeyManager()
    private let touchRing = TouchRingManager()
    private let verbose: Bool
    private let hexDump: Bool

    init(verbose: Bool, hexDump: Bool) {
        self.verbose = verbose
        self.hexDump = hexDump
        decoder.activeModel = WacomConstants.pth650
    }

    func transportDidConnect(device: IOHIDDevice) {
        let productID = (IOHIDDeviceGetProperty(device, kIOHIDProductIDKey as CFString) as? NSNumber)?.intValue
        guard productID == WacomConstants.usbProductID else {
            fputs("Unexpected HID product; PTH650Driver stays inactive.\n", stderr)
            return
        }

        let trusted = TabletEventSynthesizer.isAccessibilityTrusted(promptIfNeeded: true)
        print("Connected: Wacom Intuos5 touch M (PTH-650, 056a:0027)")
        print("Accessibility: \(trusted ? "granted" : "required")")
        print("Input: pen + pressure + tilt + eraser + 8 ExpressKeys + Touch Ring")
    }

    func transportDidDisconnect(device: IOHIDDevice) {
        decoder.reset()
        synthesizer.handleToolOutOfProximity()
        print("PTH-650 disconnected")
    }

    func transportDidFail(message: String) {
        fputs("PTH-650 transport error: \(message)\n", stderr)
    }

    func transportDidReceiveReport(reportID: UInt8, bytes: UnsafeRawBufferPointer) {
        if hexDump {
            let values = bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
            print(String(format: "raw id=0x%02X len=%d | %@", reportID, bytes.count, values))
        }
        let packets = decoder.decode(reportID: reportID, buffer: bytes)
        for packet in packets {
            handle(packet)
        }
    }

    private func handle(_ packet: ParsedPacket) {
        switch packet {
        case .pen(let pen):
            synthesizer.processPenEvent(pen)
            if verbose && pen.isHovering {
                print("pen x=\(pen.rawX) y=\(pen.rawY) pressure=\(pen.rawPressure) tilt=\(pen.rawTiltX),\(pen.rawTiltY)")
            }
        case .pad(let pad):
            expressKeys.processPadEvent(pad)
            touchRing.processPadEvent(pad)
            if verbose {
                let keys = pad.keys.map { $0 ? "1" : "0" }.joined()
                print("pad keys=\(keys) ring=\(pad.ringPosition) touched=\(pad.ringTouched) mode=\(pad.mode)")
            }
        case .toolProximity(let toolID, _, let isEraser):
            synthesizer.handleToolProximity(toolID: toolID, isEraser: isEraser)
        case .toolOutOfProximity:
            synthesizer.handleToolOutOfProximity()
        case .unknown:
            break
        }
    }
}

let verbose = CommandLine.arguments.contains("--verbose")
let hexDump = CommandLine.arguments.contains("--hex")
let noSeize = CommandLine.arguments.contains("--no-seize")
if CommandLine.arguments.contains("--help") {
    print("""
    pth650-driver — personal headless macOS driver for Wacom Intuos5 PTH-650

      --verbose   Print decoded pen, ExpressKey and Touch Ring events
      --hex       Print every raw HID report; use to capture a button/ring trace
      --no-seize  Do not seize the HID device; use only for diagnostics
      --help      Show this message
    """)
    exit(0)
}

let driver = PTH650Driver(verbose: verbose, hexDump: hexDump)
let transport = USBTransport(options: .init(seizeDevice: !noSeize, matchBluetoothPID: false))
transport.delegate = driver
transport.start()

func stopDriver(_: Int32) {
    transport.stop()
    exit(0)
}

signal(SIGINT, stopDriver)
signal(SIGTERM, stopDriver)
signal(SIGHUP, stopDriver)

print("Listening for Wacom PTH-650 (VID 056A / PID 0027). Press Ctrl+C to stop.")
RunLoop.main.run()
