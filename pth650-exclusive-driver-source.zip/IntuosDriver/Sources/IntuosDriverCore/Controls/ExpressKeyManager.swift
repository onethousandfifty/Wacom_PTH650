import Foundation
import CoreGraphics
import Carbon.HIToolbox

/// Direct keyboard actions for the personal PTH-650 driver.
/// No profiles, radial menu, display UI or application-specific controls.
public enum KeyAction: Sendable {
    case undo
    case redo
    case zoomIn
    case zoomOut
    case brushSizeIncrease
    case brushSizeDecrease
    case hand
    case eyedropper
    case keystroke(keyCode: CGKeyCode, flags: CGEventFlags)

    public var displayLabel: String {
        switch self {
        case .undo: return "Undo"
        case .redo: return "Redo"
        case .zoomIn: return "Zoom +"
        case .zoomOut: return "Zoom -"
        case .brushSizeIncrease: return "Brush +"
        case .brushSizeDecrease: return "Brush -"
        case .hand: return "Hand"
        case .eyedropper: return "Eyedropper"
        case .keystroke(let code, _): return "Key \(code)"
        }
    }
}

public final class ExpressKeyManager: @unchecked Sendable {
    private var previousKeyStates = [Bool](repeating: false, count: 8)

    /// Physical top-to-bottom PTH-650 ExpressKey defaults.
    public var keyBindings: [KeyAction] = [
        .undo,
        .redo,
        .brushSizeDecrease,
        .brushSizeIncrease,
        .hand,
        .eyedropper,
        .zoomOut,
        .zoomIn
    ]

    public init() {}

    public func processPadEvent(_ event: PadEvent) {
        for (index, isPressed) in event.keys.enumerated() where index < keyBindings.count {
            let wasPressed = previousKeyStates[index]
            if isPressed && !wasPressed {
                execute(keyBindings[index])
            }
            previousKeyStates[index] = isPressed
        }
    }

    private func execute(_ action: KeyAction) {
        switch action {
        case .undo:
            post(CGKeyCode(kVK_ANSI_Z), flags: .maskCommand)
        case .redo:
            post(CGKeyCode(kVK_ANSI_Z), flags: [.maskCommand, .maskShift])
        case .zoomIn:
            post(CGKeyCode(kVK_ANSI_Equal), flags: .maskCommand)
        case .zoomOut:
            post(CGKeyCode(kVK_ANSI_Minus), flags: .maskCommand)
        case .brushSizeIncrease:
            post(CGKeyCode(kVK_ANSI_RightBracket))
        case .brushSizeDecrease:
            post(CGKeyCode(kVK_ANSI_LeftBracket))
        case .hand:
            post(CGKeyCode(kVK_Space))
        case .eyedropper:
            post(CGKeyCode(kVK_Option), flags: .maskAlternate)
        case .keystroke(let keyCode, let flags):
            post(keyCode, flags: flags)
        }
    }

    private func post(_ keyCode: CGKeyCode, flags: CGEventFlags = []) {
        guard let down = CGEvent(keyboardEventSource: nil, virtualKey: keyCode, keyDown: true),
              let up = CGEvent(keyboardEventSource: nil, virtualKey: keyCode, keyDown: false) else {
            return
        }
        down.flags = flags
        up.flags = flags
        down.post(tap: .cghidEventTap)
        up.post(tap: .cghidEventTap)
    }
}
