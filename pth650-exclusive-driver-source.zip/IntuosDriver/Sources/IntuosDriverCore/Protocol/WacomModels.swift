import Foundation
import CoreGraphics

/// Description of the only device supported by this personal driver.
public struct WacomModelDescriptor: Sendable, Equatable {
    public let modelName: String
    public let productID: Int
    public let maxX: UInt32
    public let maxY: UInt32
    public let maxPressure: UInt16
    public let keyCount: Int
    public let hasOLED: Bool
    public let isWireless: Bool

    public init(
        modelName: String,
        productID: Int,
        maxX: UInt32,
        maxY: UInt32,
        maxPressure: UInt16 = 2047,
        keyCount: Int = 8,
        hasOLED: Bool = false,
        isWireless: Bool = false
    ) {
        self.modelName = modelName
        self.productID = productID
        self.maxX = maxX
        self.maxY = maxY
        self.maxPressure = maxPressure
        self.keyCount = keyCount
        self.hasOLED = hasOLED
        self.isWireless = isWireless
    }
}

/// Constants for Wacom Intuos5 touch M (PTH-650) only.
public enum WacomConstants {
    public static let vendorID: Int = 0x056A
    public static let usbProductID: Int = 0x0027
    public static let bluetoothProductID: Int = 0x0000

    public static let pth650 = WacomModelDescriptor(
        modelName: "Wacom Intuos5 touch M (PTH-650)",
        productID: usbProductID,
        maxX: 44704,
        maxY: 27940,
        maxPressure: 2047,
        keyCount: 8,
        hasOLED: false,
        isWireless: false
    )

    public static let supportedModels: [Int: WacomModelDescriptor] = [
        usbProductID: pth650
    ]

    public static var usbProductIDs: [Int] { [usbProductID] }

    public static func descriptor(for productID: Int) -> WacomModelDescriptor {
        supportedModels[productID] ?? pth650
    }

    public static let maxX: UInt32 = pth650.maxX
    public static let maxY: UInt32 = pth650.maxY
    public static let maxPressure: UInt16 = pth650.maxPressure
    public static let maxDistance: UInt8 = 63
    public static let tiltCenter: Int = 64
    public static let maxTiltMagnitude: Double = 64.0
    public static let expressKeyCount: Int = 8
    public static let touchRingSteps: Int = 72

    // Existing pen reports remain on the proven Trifa Studio path.
    public static let reportPenEnabled: UInt8 = 0x02
    public static let reportIntuosID1: UInt8 = 0x05
    public static let reportIntuosID2: UInt8 = 0x06
    public static let reportIntuosPen: UInt8 = 0x10

    // PTH-650 panel report. It is decoded only when it is a short frame.
    public static let reportPTH650Pad: UInt8 = 0x03

}

public struct PenEvent: Sendable, Equatable {
    public let rawX: UInt32
    public let rawY: UInt32
    public let normalizedX: Double
    public let normalizedY: Double
    public let rawPressure: UInt16
    public let normalizedPressure: Double
    public let tiltX: Double
    public let tiltY: Double
    public let rawTiltX: Int
    public let rawTiltY: Int
    public let distance: UInt8
    public let isTipDown: Bool
    public let isBarrel1: Bool
    public let isBarrel2: Bool
    public let isEraser: Bool
    public let isHovering: Bool
    public let toolID: UInt32
    public let serialNumber: UInt64
    public let timestamp: UInt64

    public init(
        rawX: UInt32,
        rawY: UInt32,
        maxX: UInt32 = WacomConstants.maxX,
        maxY: UInt32 = WacomConstants.maxY,
        rawPressure: UInt16,
        tiltX: Double,
        tiltY: Double,
        rawTiltX: Int = 0,
        rawTiltY: Int = 0,
        distance: UInt8 = 0,
        isTipDown: Bool,
        isBarrel1: Bool,
        isBarrel2: Bool,
        isEraser: Bool,
        isHovering: Bool,
        toolID: UInt32 = 0x822,
        serialNumber: UInt64 = 0,
        timestamp: UInt64 = 0
    ) {
        self.rawX = min(rawX, maxX)
        self.rawY = min(rawY, maxY)
        self.normalizedX = Double(self.rawX) / Double(max(1, maxX))
        self.normalizedY = Double(self.rawY) / Double(max(1, maxY))
        self.rawPressure = min(rawPressure, WacomConstants.maxPressure)
        self.normalizedPressure = Double(self.rawPressure) / Double(WacomConstants.maxPressure)
        self.tiltX = max(-1.0, min(1.0, tiltX))
        self.tiltY = max(-1.0, min(1.0, tiltY))
        self.rawTiltX = rawTiltX
        self.rawTiltY = rawTiltY
        self.distance = min(distance, WacomConstants.maxDistance)
        self.isTipDown = isTipDown
        self.isBarrel1 = isBarrel1
        self.isBarrel2 = isBarrel2
        self.isEraser = isEraser
        self.isHovering = isHovering
        self.toolID = toolID
        self.serialNumber = serialNumber
        self.timestamp = timestamp
    }
}

public struct PadEvent: Sendable, Equatable {
    /// Eight configurable PTH-650 ExpressKeys, indexed 0...7.
    public let keys: [Bool]
    public let ringTouched: Bool
    public let ringPosition: UInt8
    /// PTH-650 touch-ring centre button.
    public let centerButton: Bool
    /// Host-tracked touch-ring mode, 0...3.
    public let mode: UInt8

    public init(
        keys: [Bool] = [Bool](repeating: false, count: 8),
        ringTouched: Bool = false,
        ringPosition: UInt8 = 0,
        centerButton: Bool = false,
        mode: UInt8 = 0
    ) {
        var normalizedKeys = keys
        if normalizedKeys.count < 8 {
            normalizedKeys.append(contentsOf: [Bool](repeating: false, count: 8 - normalizedKeys.count))
        } else if normalizedKeys.count > 8 {
            normalizedKeys = Array(normalizedKeys.prefix(8))
        }
        self.keys = normalizedKeys
        self.ringTouched = ringTouched
        self.ringPosition = ringPosition % WacomConstants.touchRingSteps
        self.centerButton = centerButton
        self.mode = mode % 4
    }
}

public enum ParsedPacket: Sendable, Equatable {
    case pen(PenEvent)
    case pad(PadEvent)
    case toolProximity(toolID: UInt32, serial: UInt64, isEraser: Bool)
    case toolOutOfProximity
    case unknown(reportID: UInt8, length: Int)
}
