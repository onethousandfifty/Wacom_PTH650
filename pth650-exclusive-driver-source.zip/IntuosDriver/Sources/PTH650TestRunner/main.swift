import Foundation
import IntuosDriverCore

var passed = 0
var failed = 0

func expect(_ condition: @autoclosure () -> Bool, _ description: String) {
    if condition() {
        passed += 1
        print("PASS: \(description)")
    } else {
        failed += 1
        print("FAIL: \(description)")
    }
}

print("PTH650Driver synthetic tests")

let model = WacomConstants.descriptor(for: 0x0027)
expect(model.productID == 0x0027, "PTH-650 USB PID")
expect(model.maxX == 44704 && model.maxY == 27940, "PTH-650 active area")
expect(!model.hasOLED, "PTH-650 does not expose Intuos4 OLED support")

let decoder = WacomPacketDecoder()
decoder.activeModel = model

// Intuos5 short pad: report=0x03, ring=data[2], buttons=(data[4]<<1)|(data[3]&1).
// centre + ExpressKeys 0 and 3; touched ring at position 45.
let padFrame: [UInt8] = [0x03, 0x00, 0xAD, 0x01, 0x09]
let padPackets = decoder.decode(reportID: 0x03, bytes: padFrame)
if case .pad(let pad) = padPackets.first {
    expect(pad.ringTouched, "Touch Ring contact flag")
    expect(pad.ringPosition == 45, "Touch Ring position")
    expect(pad.centerButton && pad.mode == 1, "centre button advances mode")
    expect(pad.keys[0] && pad.keys[3], "ExpressKeys 0 and 3")
    expect(!pad.keys[1], "unpressed ExpressKey remains up")
} else {
    expect(false, "short report 0x03 decodes as PTH-650 panel")
}

// A long report with the same ID belongs to touch traffic, not the panel.
var touchFrame = [UInt8](repeating: 0, count: 64)
touchFrame[0] = 0x03
let touchPackets = decoder.decode(reportID: 0x03, bytes: touchFrame)
expect(touchPackets == [.unknown(reportID: 0x03, length: 64)], "long touch report is never decoded as buttons")

print("Results: \(passed) passed, \(failed) failed")
exit(failed == 0 ? 0 : 1)
